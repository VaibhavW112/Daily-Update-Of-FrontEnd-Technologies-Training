import {foo} from "./test"
//var age = 29;

function myFunction () {
    return foo;
}

myFunction ()